# GBoS GEOAI — Census & GPS Explorer

This folder contains the full static dashboard and an available district-level CSV. The dashboard automatically tries to load supported datasets from the same folder as `index.html` when hosted on GitHub Pages.

## Files included

- `index.html` — full interactive dashboard, configured for automatic data loading.
- `District_Sex_Ratio.csv` — district sex-ratio table available in the working files.

## Add these approved datasets to the repository root to enable automatic loading

- `Census_EAs_Geo.json` — EA polygon GeoJSON.
- `Settlement_Sex_Ratio.csv` — settlement sex-ratio CSV.

The dashboard will still let an authorized user upload files manually if an automatic file is missing.

## Publish on GitHub Pages

1. Create or open the GitHub repository you want to use.
2. Upload `index.html` and `District_Sex_Ratio.csv` to the repository root.
3. Only after GBoS approval, upload the EA GeoJSON and settlement CSV if they are cleared for the chosen audience.
4. Commit the files to the repository's default branch (commonly `main`).
5. Open **Settings → Pages** and configure deployment from the repository branch/root.
6. Open the published Pages URL and check the repository dataset status at the top of the data-source section.

## Data confidentiality

The available EA GeoJSON includes detailed enumeration-area boundaries and internal attributes (including staff/monitor-related fields). Do not place it in a public repository unless the responsible GBoS authority has approved that disclosure. For public demonstrations, use an approved generalized or de-identified dataset. A public repository makes its files accessible to anyone.

## Technical notes

- The page uses Leaflet, Chart.js, and PapaParse from public CDNs, so visitors need an internet connection for the libraries and basemap tiles.
- Automatic loading uses relative paths in the same folder as `index.html`.
- This is a static site; files are fetched by the visitor's browser and are not uploaded to a server by this code.
